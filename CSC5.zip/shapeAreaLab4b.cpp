/*
 * A menu drive program demonstration that will ask the user to select
 * one of several shapes, ask the user for the parameters of that
 * shape, then will calulate and output certain characteristics of
 * that shape.
 *
 */

/* 
 * File:   shapeAreaLab4b.cpp
 * Author: Ahmad okde
 * Created on March 18, 2020, 1:53 PM
 */

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std ;


// define PI as a named constant
const double PI = 3.1415926;
/*
* Main Program
*
* Present a menu of shapes to the user. The user will select one of
* the objects and enter the appropriate parameters. The perimeter
* and area of the shape will be displayed. The menu selections are
* are:
*
* Quit
* Triangle
* Square
* Rectangle
* Circle
* Ellipse (optional challenge)
*/
int main() {
	int choice;
	float area, perimeter;
	while (true)
	{
		// Put your menu display and user prompt code here
		cout << endl;
		cout << "0. Quit" << endl;
		cout << "1. Triangle" << endl;
		cout << "2. Square" << endl;
		cout << "3. Rectangle" << endl;
		cout << "4. Circle" << endl;

		cout << "Enter choice: ";
		cin >> choice;

		// Put your if/if else statements here
		if (choice==1)
		{
			float a, b, c;

			cout << "Enter a: ";
			cin >> a;
			cout << "Enter b: ";
			cin >> b;
			cout << "Enter c: ";
			cin >> c;
			float s = (a+b+c)/2;

			area = sqrt(s*(s-a) * (s-b)*(s-c));
			perimeter = a+b+c;
			cout  << "Area of triangle: " << setprecision(2) << fixed << area << endl;
			cout << "Perimeter of triangle: " << setprecision(2) << fixed << perimeter << endl;
		}
		else if (choice==2)
		{
			float side;
			cout << "Enter side of square: ";
			cin >> side;
			area = side * side;
			perimeter = 4 * side;
			cout << "Area of Square: " << setprecision(2) << fixed << area << endl;
			cout << "Perimeter of Square: " << setprecision(2) << fixed << perimeter << endl;
		}
		else if (choice==3)
		{
			float width, height;
			cout << "Enter width: ";
			cin >> width;
			cout << "Enter height: ";
			cin >> height;
			area = width * height;
			perimeter = 2*(width + height);
			cout  << "Area of rectangle: " << setprecision(2) << fixed << area << endl;
			cout << "Perimeter of rectangle: " << setprecision(2) << fixed << perimeter << endl;
		}
		else if (choice==4)
		{
			float radius;
			cout << "Enter radius of circle: ";
			cin >> radius;
			area = PI * radius * radius;
			perimeter = 2 * PI * radius;
			cout  << "Area of Circle: " << setprecision(2) << fixed << area << endl;
			cout << "Perimeter of Circle: " << setprecision(2) << fixed << perimeter << endl;
		}
		
		else if (choice==0)
		{
			cout << "Thank you for using the program\n\n";	
			exit(0);
		}
		else
		{
			cout << "Invalid option entered\n";
		}
		
	} // end of while loop
	return 0;
}
